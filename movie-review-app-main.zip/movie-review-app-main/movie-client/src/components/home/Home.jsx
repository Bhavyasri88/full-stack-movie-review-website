import React from 'react'
import Hero from '../hero/Hero';

const Home = () => {
  return (
    <div>
      <Hero />
    </div>
  )
}

export default Home;